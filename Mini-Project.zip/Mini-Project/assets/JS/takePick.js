
var webcamElement, canvasElement, snapSoundElement, webcam;
function initializeCam( webcamEle, canvasEle, snapSoundEle)
{
   webcamElement = webcamEle;
 canvasElement = canvasEle;
 snapSoundElement = snapSoundEle;
  webcam = new Webcam(webcamElement, 'user', canvasElement, null);
}

function start()
{
webcam.start()
  .then(result => {
    console.log("webcam started");
    return(1);
  })
  .catch(err => {
    console.log(err);
    return(0);
  });
}

function addText(text)
{
  var ctx = canvasElement.getContext('2d');

  ctx.translate(canvasElement.width / 2, canvasElement.height / 2);
  ctx.scale(-1, 1);
  ctx.font = "30px Comic Sans MS";
  ctx.fillStyle = "red";
  ctx.textAlign = "center";
  ctx.fillText(text,0, 0);
  console.log("text get printed on image -----------------------------------------------------");
}


function takePic()
{
let picture = webcam.snap();
return(picture);
}


function stop()
{
webcam.stop();
}

function test()
{
  console.log("Hii hello");
}

//------------------- zoom analysis-------------------

function imageZoom(imgID, resultID) {


  var img, lens, result, cx, cy;
  img = document.getElementById(imgID);
  result = document.getElementById(resultID);
  /*create lens:*/
  lens = document.createElement("DIV");
  lens.setAttribute("class", "img-zoom-lens");
  /*insert lens:*/
  img.parentElement.insertBefore(lens, img);
  /*calculate the ratio between result DIV and lens:*/
  cx = result.offsetWidth / lens.offsetWidth;
  cy = result.offsetHeight / lens.offsetHeight;
  /*set background properties for the result DIV:*/
  result.style.backgroundImage = "url('" + img.src + "')";
  result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";
  /*execute a function when someone moves the cursor over the image, or the lens:*/
  lens.addEventListener("mousemove", moveLens);
  img.addEventListener("mousemove", moveLens);
  /*and also for touch screens:*/
  lens.addEventListener("touchmove", moveLens);
  img.addEventListener("touchmove", moveLens);
  function moveLens(e) {
    var pos, x, y;
    /*prevent any other actions that may occur when moving over the image:*/
    e.preventDefault();
    /*get the cursor's x and y positions:*/
    pos = getCursorPos(e);
    /*calculate the position of the lens:*/
    x = pos.x - (lens.offsetWidth / 2);
    y = pos.y - (lens.offsetHeight / 2);
    /*prevent the lens from being positioned outside the image:*/
    if (x > img.width - lens.offsetWidth) { x = img.width - lens.offsetWidth; }
    if (x < 0) { x = 0; }
    if (y > img.height - lens.offsetHeight) { y = img.height - lens.offsetHeight; }
    if (y < 0) { y = 0; }
    /*set the position of the lens:*/
    lens.style.left = x + "px";
    lens.style.top = y + "px";
    /*display what the lens "sees":*/
    result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
  }
  function getCursorPos(e) {
    var a, x = 0, y = 0;
    e = e || window.event;
     //console.log("--------------------------------------");

    /*get the x and y positions of the image:*/
    a = img.getBoundingClientRect();
    /*calculate the cursor's x and y coordinates, relative to the image:*/
    x = e.pageX - a.left;
    y = e.pageY - a.top;
    /*consider any page scrolling:*/
    x = x - window.pageXOffset;
    y = y - window.pageYOffset;
    return { x: x, y: y };
  }
}
//-------------------- end--------------------------------------


let classifier;

// A variable to hold the image we want to classify
let img;
let imageModelURL = 'https://teachablemachine.withgoogle.com/models/4m8JVEUCm/';



function preload() {
  classifier = ml5.imageClassifier(imageModelURL + 'model.json');
  img = loadImage('https://o.quizlet.com/A9Q.h40OIrECQmkH9MWRYQ_b.jpg');


}

let myresult;
function loaded(imgBase64) {
  img = loadImage(imgBase64);
  setup();
  //console.log(myresult);
  return(myresult);
}

function setup() {
  createCanvas(400, 400);


  classifier.classify(img, gotResult);
  image(img, 0, 0);
}


// A function to run when we get any errors and the results
function gotResult(error, results) {
  // Display error in the console
  if (error) {
    console.error(error);
  } else {
    // The results are in an array ordered by confidence.
    console.log(results)
    console.log('   +77777777777777777777777777777777777777777777777777777777');
    if(results[0].confidence >= 0.95){
    myresult = results[0].label;
    }
    else
    {
      myresult ="Class 3";
    }
  }
}
