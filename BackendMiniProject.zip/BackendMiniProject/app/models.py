from django.db import models

# Create your models here.


class patientInfo(models.Model):
    patientName = models.CharField(max_length=100)
    patientProfile = models.URLField(blank=True)
    patientGmailid = models.CharField(max_length=200)
    patientPassword = models.CharField(max_length=20)
    patientPhonenumber = models.CharField(max_length=10)

class doctorInfo(models.Model):
    doctorName = models.CharField(max_length=200)
    doctorProfile = models.URLField(blank=True)
    doctorUPI = models.URLField(blank=True)
    doctorGmailid = models.CharField(max_length=100)
    doctorPassword = models.CharField(max_length=200)
    doctorPhonenumber = models.CharField(max_length=20)
    doctorDegree = models.CharField(max_length=200)

class deliveryboyInfo(models.Model):
    deliveryboyName = models.CharField(max_length=200)
    deliveryboyProfile = models.URLField(blank=True)
    deliveryboyUPI = models.URLField(blank=True)
    deliveryboyPassword = models.CharField(max_length=200)
    deliveryboyGmailid = models.CharField(max_length=200)
    deliveryboyPhonenumber = models.CharField(max_length=20)


class patientReport(models.Model):
    img1 = models.URLField()
    img2 = models.URLField()
    img3 = models.URLField()
    img4 = models.URLField()
    img5 = models.URLField()
    reportAccurate = models.CharField(max_length=100,blank=True)
    patientobj = models.ForeignKey(
        to=patientInfo, on_delete=models.CASCADE)
    
    doctorGmailid = models.CharField(max_length=200 ,blank=True)

    upiDoctor = models.CharField(blank=True,max_length=200)
    diseaseClass = models.IntegerField(blank=True,default=-1)
    acceptReq     = models.IntegerField(default=0)
    prescription = models.CharField(blank=True,default="",max_length=10000)
    predictedprescription = models.CharField(blank=True, default="", max_length=10000)
    feedback = models.IntegerField(default=-1)

class deliveryInfo(models.Model):

    patientReportObj = models.ForeignKey(to=patientReport, on_delete=models.CASCADE)
    patientGmailid   = models.CharField(max_length=50)
    deliveryboyGmailId = models.CharField(blank=True,max_length=50)
    OrderDetails = models.CharField(blank=True , max_length=10000)
    Amount = models.IntegerField(default=0)
    address = models.CharField(max_length=5000)
    requestState = models.IntegerField(default=0)
    deliveryStatus = models.IntegerField(default=0)

class chartingBox(models.Model):
    sendmailId = models.CharField(max_length=30)
    receiverId = models.CharField(max_length=30)
    reportId = models.CharField(max_length=10)
    message  = models.CharField(max_length=250)
    time     = models.CharField(max_length=30)

class activeUsers(models.Model):
    usermailId = models.CharField(max_length=200)
    typeUser = models.IntegerField()
    activeStatus = models.CharField(max_length=10)


