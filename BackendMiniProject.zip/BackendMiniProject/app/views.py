import os
import threading
from app.models import activeUsers
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
import ast

import cv2
import numpy as np

from keras.preprocessing.image import ImageDataGenerator as ImageDataGen

from keras.models import Sequential
from keras.layers import Activation, Dropout, Flatten, Conv2D, MaxPooling2D, Dense
#from keras.models import Sequential
from keras.preprocessing import image
import keras
from PIL import Image
import base64
from keras.models import load_model

from io import BytesIO
from keras import backend as K
import tensorflow as tf

import  os;


backendOrgin = "http://localhost:8000"
### database import statements
from django.db.models import Q
import os
from app.models import patientInfo
from app.models import deliveryboyInfo
from app.models import doctorInfo
from app.models import patientReport
from app.models import activeUsers
from app.models import deliveryInfo
import threading as thread
from BackendMiniProject.settings import BASE_DIR
import json
from ast import literal_eval 
from app.models import chartingBox
from app.models import deliveryInfo

from django.core.mail import EmailMultiAlternatives
###


# image_gen = ImageDataGen(rotation_range=150,
#                          width_shift_range=0.1,
#                          height_shift_range=0.1,
#                          rescale=1/255,
#                          shear_range=0.2,
#                          zoom_range=0.2,
#                          horizontal_flip=True,
#                          #                           vertical_flip = True,
#                          fill_mode='nearest'
#                          )
# # keras.backend.clear_session()

# model = Sequential()
# model.add(Conv2D(filters=32,
#                  kernel_size=(3, 3),
#                  input_shape=(150, 150, 3),
#                  activation="relu"
#                  ))

# model.add(MaxPooling2D(pool_size=(2, 2)))

# model.add(Conv2D(filters=64,
#                  kernel_size=(3, 3),
#                  input_shape=(150, 150, 3),
#                  activation="relu"
#                  ))
# model.add(MaxPooling2D(pool_size=(2, 2)))


# model.add(Conv2D(filters=128,
#                  kernel_size=(3, 3),
#                  input_shape=(150, 150, 3),
#                  activation="relu"
#                  ))
# model.add(MaxPooling2D(pool_size=(2, 2)))

# model.add(Conv2D(filters=256,
#                  kernel_size=(3, 3),
#                  input_shape=(150, 150, 3),
#                  activation="relu"
#                  ))
# model.add(MaxPooling2D(pool_size=(2, 2)))


# model.add(Flatten())
# model.add(Dense(128))
# model.add(Activation("relu"))
# model.add(Dropout(0.5))
# model.add(Dense(1))
# model.add(Activation('sigmoid'))
# model.compile(loss="binary_crossentropy",
#               optimizer='adam',
#               metrics=["accuracy"]
#               )

# input_shape = (150, 150, 3)
# batch_size = 16
# train_image_gen = image_gen.flow_from_directory("C:/Users/umgkr/Desktop/project dataset/archive/",
#                                                 target_size=input_shape[:2],
#                                                 batch_size=batch_size,
#                                                 class_mode="binary"
#                                                 )

# test_image_gen = image_gen.flow_from_directory("C:/Users/umgkr/Desktop/project dataset/archive/",
#                                                target_size=input_shape[:2],
#                                                batch_size=batch_size,
#                                                class_mode="binary"
#                                                )


# results = model.fit_generator(train_image_gen,
#                               epochs=3,
#                               steps_per_epoch=150,
#                               validation_data=test_image_gen,
#                               validation_steps=12
#                               )

# print("hello")

# print(results.history['acc'])
# model.save('model.h5')
#graph = tf.get_default_graph()
graph = tf.compat.v1.get_default_graph()
serverOrgin = 'https://bcdc452a9939.ngrok.io'
# # model1.save('model.h5')


# print("hello")

# def skin():
#     img = cv2.imread(
#         "C:/Users/umgkr/Desktop/project dataset/skin-lesions/test/melanoma/ISIC_0012258.jpg")
#     img = cv2.resize(img[:, :, :3], (150, 150))
#     # cv2.imwrite("app/media/kjf.jpg",img[:,:,::-1])

#     img = img[:, :, ::-1]
#     print(img.shape)
#     img = np.array(img, dtype="float32")
#     img = np.expand_dims(img, axis=0)
#     img = img/img.max()
#     img = np.array(img, dtype="float32")
#     # print(type(img[0][0][0][0]))

#     SkinDisease = model1.predict_classes(img)
#     print(SkinDisease)


# class sd:

#     def __init__(self,a,b):
#         self.a =a
#         self.b =b
#     def fun(self):
#         print(self.a)
# obj = sd(10,20)
@csrf_exempt
def skinDiseasePredictor(request):
    if request.method == "POST":
#         image_gen = ImageDataGen(rotation_range=150,
#                                  width_shift_range=0.1,
#                                  height_shift_range=0.1,
#                                  rescale=1/255,
#                                  shear_range=0.2,
#                                  zoom_range=0.2,
#                                  horizontal_flip=True,
#                                  #                           vertical_flip = True,
#                                  fill_mode='nearest'
#                                  )
# # keras.backend.clear_session()


#         model1 = Sequential()
#         model1.add(Conv2D(filters=32,
#                   kernel_size=(3, 3),
#                   input_shape=(150, 150, 3),
#                   activation="relu"
#                   ))

#         model1.add(MaxPooling2D(pool_size=(2, 2)))

#         model1.add(Conv2D(filters=64,
#                   kernel_size=(3, 3),
#                   input_shape=(150, 150, 3),
#                   activation="relu"
#                   ))
#         model1.add(MaxPooling2D(pool_size=(2, 2)))


#         model1.add(Conv2D(filters=32,
#                   kernel_size=(3, 3),
#                   input_shape=(150, 150, 3),
#                   activation="relu"
#                   ))
#         model1.add(MaxPooling2D(pool_size=(2, 2)))

#         model1.add(Conv2D(filters=64,
#                   kernel_size=(3, 3),
#                   input_shape=(150, 150, 3),
#                   activation="relu"
#                   ))
#         model1.add(MaxPooling2D(pool_size=(2, 2)))


#         model1.add(Flatten())
#         model1.add(Dense(128))
#         model1.add(Activation("relu"))
#         model1.add(Dropout(0.5))
#         model1.add(Dense(1))
#         model1.add(Activation('sigmoid'))
#         model1.compile(loss="binary_crossentropy",
#                optimizer='adam',
#                metrics=["accuracy"]
#                )

#         input_shape = (150, 150, 3)
#         batch_size = 16
#         train_image_gen = image_gen.flow_from_directory("C:/Users/umgkr/Desktop/project dataset/skin-lesions/train",
#                                                 target_size=input_shape[:2],
#                                                 batch_size=batch_size,
#                                                 class_mode="binary"
#                                                 )

#         test_image_gen = image_gen.flow_from_directory("C:/Users/umgkr/Desktop/project dataset/skin-lesions/test",
#                                                target_size=input_shape[:2],
#                                                batch_size=batch_size,
#                                                class_mode="binary"
#                                                )


#         results = model1.fit_generator(train_image_gen,
#                                epochs=1,
#                                steps_per_epoch=150,
#                                validation_data=test_image_gen,
#                                validation_steps=12
#                                )

#         print("hello")
        global graph

        request_data = request.body.decode(
            'utf-8')
       # print(len(request_data))    
        # imageobj = testUrl(request_data)
        # imageobj.save()
        decoded = base64.b64decode(request_data[22:])

        print(len(request_data[22:]))
        img = np.array(Image.open(BytesIO(decoded)), dtype=float)

        with graph.as_default():
            # K.clear_session()


            modelloadedObj = load_model('model.h5')
            # img = cv2.imread(
            # "C:/Users/umgkr/Desktop/project dataset/skin-lesions/test/melanoma/ISIC_0012258.jpg")
            img = cv2.resize(img[:, :, :3], (150, 150))
    # cv2.imwrite("app/media/kjf.jpg",img[:,:,::-1])

            img = img[:, :, ::-1]
            print(img.shape)
            img = np.array(img, dtype="float32")
            img = np.expand_dims(img, axis=0)
            img = img/img.max()
            img = np.array(img, dtype="float32")
    # print(type(img[0][0][0][0]))

            SkinDisease = modelloadedObj.predict_classes(img)
            print(SkinDisease[0][0])




         

        #     decoded = base64.b64decode(request_data[22:])

        #     print(len(request_data[22:]))
        #     img = np.array(Image.open(BytesIO(decoded)), dtype=float)
        # img = np.expand_dims(img, axis=0)
            # img = cv2.resize(img[:,:,:3], (150,150))
        # # cv2.imwrite("app/media/kjf.jpg",img[:,:,::-1]) 
        
        # img = img[:,:,::-1]
        # print(img.shape)
        # img = np.array(img,dtype="float32")
        # img = np.expand_dims(img,axis=0)
        # img = img/img.max()
        # img = np.array(img,dtype="float32")
        # # print(type(img[0][0][0][0]))

        # SkinDisease = model.predict_classes(img)
        # img = cv2.imread(
        #     "C:/Users/umgkr/Desktop/project dataset/skin-lesions/test/melanoma/ISIC_0012258.jpg")
        # img = cv2.resize(img[:, :, :3], (150, 150))
        # # cv2.imwrite("app/media/kjf.jpg",img[:,:,::-1])

        # img = img[:, :, ::-1]
        # print(img.shape)
        # img = np.array(img, dtype="float32")
        # img = np.expand_dims(img, axis=0)
        # img = img/img.max()
        # img = np.array(img, dtype="float32")
        # print(type(img[0][0][0][0]))

        # SkinDisease = model.predict_classes(img)
        # print(SkinDisease)'
        # keras.backend.clear_session()

        # obj.fun()

    return(HttpResponse(SkinDisease[0][0]))



@csrf_exempt
def Registration(request):
    if request.method =='POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        validationResult =[0,0]
        if result['userType'] == 0:
            validationResult = ValidationData(result ,typeuser = 0)
            if validationResult[0] == 1 and validationResult[1]==1:
                imgURL = getImageUrl(result['imgBase64'], result['emailid'],result['userType'])
                if imgURL == '0':
                    validationResult.append(0)
                    return HttpResponse(str(validationResult))

                patientInfoObj = patientInfo(patientName=result['username'],
                                            patientProfile=imgURL,
                                            patientGmailid=result['emailid'],
                                            patientPassword=result['password'],
                                            patientPhonenumber=result['phonenumber'])
                patientInfoObj.save()
                activeUserObj = activeUsers(
                    usermailId=result['emailid'], typeUser=0, activeStatus="inactive")
                activeUserObj.save()

        elif result['userType'] == 1:
            validationResult = ValidationData(result ,typeuser = 1)
            if validationResult[0] == 1 and validationResult[1] == 1:
                imgURL = getImageUrl(result['imgBase64'], result['emailid'], result['userType'])
                upiURL = getImageUrl(result['upiDoctor'], result['emailid'], result['userType'],1)

                if imgURL == '0':
                    validationResult.append(0)
                    validationResult.append(1)
                    return HttpResponse(str(validationResult))
                if upiURL == '0':
                    validationResult.append(1)
                    validationResult.append(0)
                    return HttpResponse(str(validationResult))

                doctorInfoObj = doctorInfo(doctorName=result['username'],
                                                doctorProfile=imgURL,
                                                doctorUPI=upiURL,
                                                doctorGmailid=result['emailid'],
                                                doctorPassword=result['password'],
                                                doctorPhonenumber=result['phonenumber'],
                                                doctorDegree=result['professionDegree'])

                activeUserObj = activeUsers(usermailId=result['emailid'], typeUser=1, activeStatus="inactive")
                activeUserObj.save()
                doctorInfoObj.save()
                print(doctorInfoObj.doctorPhonenumber);
                print(result['phonenumber'])
        else:
            print("type 2")
            validationResult = ValidationData(result ,typeuser = 2)
            if validationResult[0] == 1 and validationResult[1] == 1:
                imgURL = getImageUrl(result['imgBase64'], result['emailid'], result['userType'])
                upiURL = getImageUrl(result['upiDeliveryBoy'], result['emailid'], result['userType'],1)

                if imgURL == '0':
                    validationResult.append(0)
                    validationResult.append(1)
                    return HttpResponse(str(validationResult))
                if upiURL == '0':
                    validationResult.append(1)
                    validationResult.append(0)
                    return HttpResponse(str(validationResult))

                deliveryboyInfoObj = deliveryboyInfo(deliveryboyName=result['username'],
                                           deliveryboyProfile=imgURL,
                                           deliveryboyUPI = upiURL,
                                           deliveryboyGmailid=result['emailid'],
                                           deliveryboyPassword=result['password'],
                                           deliveryboyPhonenumber=result['phonenumber'])
                activeUserObj = activeUsers(
                    usermailId=result['emailid'], typeUser=2, activeStatus="inactive")
                activeUserObj.save()
                deliveryboyInfoObj.save()

        validationResult.append(1)
        validationResult.append(1)
        print(validationResult)
        return(HttpResponse(str(validationResult)))








@csrf_exempt
def formValidation(request):
    valid = [0]
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)

        if result["typeUser"] == 0:
            if len(patientInfo.objects.filter(patientGmailid = result['gmailid'] , patientPassword = result['password']))==1:
                valid = [1]
        elif result["typeUser"] == 1:
            if len(doctorInfo.objects.filter(doctorGmailid=result['gmailid'] , doctorPassword=result['password']))==1:
                valid = [1]
        else:
            if len(deliveryboyInfo.objects.filter(deliveryboyGmailid=result['gmailid'],deliveryboyPassword=result['password']))==1:
                valid = [1]

        return HttpResponse(str(valid))




def ValidationData(result , typeuser):
    gmailidError=0
    phoneNumber =0
     
    if typeuser ==0:
        if len(patientInfo.objects.filter(patientGmailid=result['emailid']))==0:
            gmailidError=1
        if len(patientInfo.objects.filter(patientPhonenumber=result['phonenumber'])) == 0:
            phoneNumber = 1
    elif typeuser == 1:
        if len(doctorInfo.objects.filter(doctorGmailid=result['emailid'])) == 0:
            gmailidError = 1
        if len(doctorInfo.objects.filter(doctorPhonenumber=result['phonenumber'])) == 0:
            phoneNumber = 1
    else:
        if len(deliveryboyInfo.objects.filter(deliveryboyGmailid=result['emailid'])) == 0:
            gmailidError = 1
        if len(deliveryboyInfo.objects.filter(deliveryboyPhonenumber=result['phonenumber'])) == 0:
            phoneNumber = 1
    return [gmailidError, phoneNumber ]



@csrf_exempt
def imageTest(request):
    request_data = request.body.decode('utf-8')
    res = ast.literal_eval(request_data)
    print(getImageUrl(res['imgBase64']))
    return(HttpResponse("\" recived \""))

#------------------------------------- get profile url --------------------------------------------
def getImageUrl(imgBase64 , gmailid ="default@gmail.com" , userType = -1 , profileOrupi = 0):
    filepath = os.path.dirname(os.path.abspath(__file__))
    print(filepath)

    #filename = 'kgf.jpg' # generate a file name write logic
    count = 0
    if userType == 0:
        count = len(patientInfo.objects.filter(patientGmailid=gmailid))
    elif userType == 1:
        count = len(doctorInfo.objects.filter(doctorGmailid=gmailid))
    else:
        count = len(deliveryboyInfo.objects.filter(deliveryboyGmailid=gmailid))
    filename = gmailid+str(userType)+str(count + profileOrupi)+'.jpg'
    filepath = os.path.join(filepath, 'media', 'profile', filename)
    decoded = base64.b64decode(imgBase64[22:])
    try:
        img = np.array(Image.open(BytesIO(decoded)), dtype='int32')[:,:,:3]
        print(img.shape)
        cv2.imwrite(filepath, img[:,:,::-1])
    except: 
        return("0")

    return(backendOrgin+'/media/profile/'+filename)
#-------------------------end ------------------------------------------

#--------------------- get report image url----------------------------------
@csrf_exempt
def getReport(request):

    if request.method =='POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportUrlList=[]
        print(result['gmailid'])
        imageCount=1
        for i in result['reportImg']:
            reportUrlList.append(getReportUrl(i, result['gmailid'],imageCount))
            imageCount+=1
        patientReportObj = patientReport(
            patientobj=patientInfo.objects.get(patientGmailid=result['gmailid']),
                img1=reportUrlList[0],
                img2=reportUrlList[1],
                img3 = reportUrlList[2],
                img4=reportUrlList[3],
                img5=reportUrlList[4])
        patientReportObj.save()

        
        # img1 = cv2.imread(patientReportObj.img1)[:,:,::-1]
        # img2 = cv2.imread(patientReportObj.img2)[:, :, ::-1]
        # img3 = cv2.imread(patientReportObj.img3)[:, :, ::-1]
        # img4 = cv2.imread(patientReportObj.img4)[:, :, ::-1]
        # img5 = cv2.imread(patientReportObj.img5)[:, :, ::-1]

        # imgSet = img1.copy()
        # imgSet = np.array(imgSet,dtype='float32')/255
        # ScannerSkinDiseasePredictor(imgSet)
        # print(reportUrlList[0])
        reportAcc =[]
        
        imgSet = np.array(cv2.imread(os.path.join(BASE_DIR,'app','media',
                                                   'data',patientReportObj.img1.split('/')[-1])), dtype='float32')/255
        print(imgSet)
        result=ScannerSkinDiseasePredictor(imgSet)
        reportAcc.append(result)
        
        imgSet = np.array(cv2.imread(os.path.join(BASE_DIR, 'app', 'media',
                                                  'data', patientReportObj.img2.split('/')[-1])), dtype='float32')/255
        result = ScannerSkinDiseasePredictor(imgSet)
        reportAcc.append(result)

        imgSet = np.array(cv2.imread(os.path.join(BASE_DIR, 'app', 'media',
                                                  'data', patientReportObj.img3.split('/')[-1])), dtype='float32')/255
        result = ScannerSkinDiseasePredictor(imgSet)
        reportAcc.append(result)

        imgSet = np.array(cv2.imread(os.path.join(BASE_DIR, 'app', 'media',
                                                  'data', patientReportObj.img4.split('/')[-1])), dtype='float32')/255
        result = ScannerSkinDiseasePredictor(imgSet)
        reportAcc.append(result)

        imgSet = np.array(cv2.imread(os.path.join(BASE_DIR, 'app', 'media',
                                                  'data', patientReportObj.img5.split('/')[-1])), dtype='float32')/255
        result = ScannerSkinDiseasePredictor(imgSet)
        reportAcc.append(result)

        patientReportObj.reportAccurate = str(reportAcc)
        patientReportObj.save()
        maxi=0
        PredicatedClass =-1
        for i in reportAcc:
            data = i
            try:
                if float(data[1])>maxi:
                    maxi=float(data[1])
                    PredicatedClass = int(data[0])
            except :
                patientReportObj.delete()
        if PredicatedClass == 0:
            patientReportObj.predictedprescription = "Benign refers to a condition, tumor, or growth that is not cancerous. This means that it does not spread to other parts of the body. It does not invade nearby tissue. Sometimes, a condition is called benign to suggest it is not dangerous or serious.|| Alfuzosin(Uroxatral)|| Doxazosin(Cardura) || Prazosin(Minipress) || Silodosin(Rapaflo) || Tamsulosin(Flomax) || Terazosin(Hytrin)"
        elif PredicatedClass == 1:
            patientReportObj.predictedprescription = "(muh-LIG-nun-see) A term for diseases in which abnormal cells divide without control and can invade nearby tissues. Malignant cells can also spread to other parts of the body through the blood and lymph systems.|| BEACOPP|| BEAM||Bendamustine (Levact) ||Bevacizumab (Avastin)|| Bexarotene (Targretin)|| Bicalutamide (Casodex)|| Bleomycin.|| Bleomycin, etoposide and platinum (BEP)"
        
        patientReportObj.diseaseClass = PredicatedClass
        patientReportObj.save()

        return(HttpResponse(PredicatedClass))


def ScannerSkinDiseasePredictor(imgSet):
    with graph.as_default():
        modelloadedObj = load_model('model.h5')

        imgSet = cv2.resize(imgSet,(150,150))
        img = np.expand_dims(imgSet, axis=0)
        SkinDisease = (modelloadedObj.predict(img) > 0.5).astype("int32")
        SkinDiseaseProbability = modelloadedObj.predict(img)
        print(SkinDisease[0][0])
        print(SkinDiseaseProbability[0][0])
        return([SkinDisease[0][0], SkinDiseaseProbability[0][0]])
        #return([ SkinDisease[0][0] , SkinDiseaseProbability[0][0] ])
        #print(SkinDiseaseProbability)


def getReportUrl(reportImg64,gmailid,imgCount):
    record = len(patientReport.objects.filter(patientobj = patientInfo.objects.get(patientGmailid=gmailid)))
    fileName = gmailid+str(record*5+imgCount)+".jpg"
    filepath = os.path.join(BASE_DIR,'app', 'media', 'data', fileName)
    decoded = base64.b64decode(reportImg64[22:])
    img = np.array(Image.open(BytesIO(decoded)), dtype='int32')[:,:,:3]
    print(img.shape)
    cv2.imwrite(filepath, img[:,:,::-1])
    return(backendOrgin+'/media/data/'+fileName)

#----------------------------end------------------------------------------

#-----------------------placeRequest To Doctor ---------------------------

@csrf_exempt
def placeRequest(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        patientReportObj = patientReport.objects.get(id=result['id'])
        patientReportObj.requestDoctor = 'placed'
        patientReportObj.save()
        return HttpResponse('done')
#----------------------------end-------------------------------------------

#--------------------------- Doctor view the request -------------

@csrf_exempt
def DoctorAcceptRequest(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        patientReportObj = patientReport.objects.get(id=result['id'])
        patientReportObj.doctorGmailid = result['gmailid']
        patientReportObj.save()
        return(HttpResponse('done'))
#------------------------------------End-----------------------------

#----------------- Reports------------------------------------------------


@csrf_exempt
def showReportToDoctor(request):

    if request.method =='POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)

        reportList=[]

        for report in patientReport.objects.filter(patientobj=patientInfo.objects.get(patientGmailid =result['gmailid'])):
            if report.doctorGmailid == '':
                reportInfo = {
                    'id':report.id,
                    'img1': report.img1.replace('http://localhost:8000', serverOrgin),
                    'img2': report.img2.replace('http://localhost:8000', serverOrgin),
                    'img3': report.img3.replace('http://localhost:8000', serverOrgin),
                    'img4': report.img4.replace('http://localhost:8000', serverOrgin),
                    'img5': report.img5.replace('http://localhost:8000', serverOrgin),
                    'predictedprescription': report.predictedprescription,
                    'prescription': report.prescription,
                    'reportAccurate': list(report.reportAccurate),
                    'raiseRequestStatus':0
                            }
            else:
                doctorObj = doctorInfo.objects.get(doctorGmailid=report.doctorGmailid)
                reportInfo = {
                    'id': report.id,
                    'img1': report.img1.replace('http://localhost:8000', serverOrgin),
                    'img2': report.img2.replace('http://localhost:8000', serverOrgin),
                    'img3': report.img3.replace('http://localhost:8000', serverOrgin),
                    'img4': report.img4.replace('http://localhost:8000', serverOrgin),
                    'img5': report.img5.replace('http://localhost:8000', serverOrgin),
                    'predictedprescription': report.predictedprescription,
                    'prescription': report.prescription,
                    'reportAccurate': report.reportAccurate,
                    'raiseRequestStatus': 1,
                    'acceptStatus': report.acceptReq,
                    'doctorUpi': doctorObj.doctorUPI.replace('http://localhost:8000', serverOrgin),
                    'doctorName': doctorObj.doctorName,
                    'doctorProfile': doctorObj.doctorProfile.replace('http://localhost:8000', serverOrgin),
                    'doctorPhonenumber':doctorObj.doctorPhonenumber
                          }

            reportList.append(reportInfo)

        return HttpResponse(json.dumps(reportList))
@csrf_exempt
def getRecordById(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        report = patientReport.objects.get(id = result['id'])
        if report.doctorGmailid == '':
                reportInfo = {
                    'id': report.id,
                    'img1': report.img1.replace('http://localhost:8000', serverOrgin),
                    'img2': report.img2.replace('http://localhost:8000', serverOrgin),
                    'img3': report.img3.replace('http://localhost:8000', serverOrgin),
                    'img4': report.img4.replace('http://localhost:8000', serverOrgin),
                    'img5': report.img5.replace('http://localhost:8000', serverOrgin),
                    'predictedprescription': report.predictedprescription,
                    'prescription': report.prescription,
                    'reportAccurate': json.loads(report.reportAccurate),
                    'raiseRequestStatus': 0
                            }
        else:
                doctorObj = doctorInfo.objects.get(doctorGmailid=report.doctorGmailid)
                reportInfo = {
                    'id': report.id,
                    'img1': report.img1.replace('http://localhost:8000', serverOrgin),
                    'img2': report.img2.replace('http://localhost:8000', serverOrgin),
                    'img3': report.img3.replace('http://localhost:8000', serverOrgin),
                    'img4': report.img4.replace('http://localhost:8000', serverOrgin),
                    'img5': report.img5.replace('http://localhost:8000', serverOrgin),
                    'predictedprescription': report.predictedprescription,
                    'prescription': report.prescription,
                    'reportAccurate':json.loads(report.reportAccurate),
                    'raiseRequestStatus': 1,
                    'acceptStatus': report.acceptReq,
                    'doctorUpi': doctorObj.doctorUPI.replace('http://localhost:8000', serverOrgin),
                    'doctorName': doctorObj.doctorName,
                    'doctorProfile': doctorObj.doctorProfile.replace('http://localhost:8000', serverOrgin),
                    'doctorGmailId':doctorObj.doctorGmailid,
                    'doctorPhonenumber':doctorObj.doctorPhonenumber
                          }
        return(HttpResponse(json.dumps(reportInfo)))
    return(HttpResponse(json.dumps('hello')))
#---------------------end----------------

#----------------- doctor request -------------- patient Side

@csrf_exempt
def patientRequestToDoctor(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = patientReport.objects.get(id = result['reportId'])
        reportId.doctorGmailid = doctorInfo.objects.get(id = result['doctorId']).doctorGmailid
        reportId.save()
        return(HttpResponse(json.dumps('success')))
#-------------------end---------------------------

#--------------- Doctor monitor patient ----------
@csrf_exempt
def doctorAcceptMonitoringPatient(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportMonitorList = []
        doctorGmailid = result['doctorGmailid']
        reportObjList = patientReport.objects.filter(doctorGmailid = doctorGmailid)
        for reportObj in reportObjList:

            if reportObj.acceptReq in [0,1]:
                    reportRequest =  {
                            'patientName': reportObj.patientobj.patientName,
                            'patientProfile': reportObj.patientobj.patientProfile.replace('http://localhost:8000', serverOrgin),
                            'reportId': reportObj.id,
                            'acceptStatus':reportObj.acceptReq
                                     }
            else:
                    reportRequest = {
                             'patientName': reportObj.patientobj.patientName,
                             'patientProfile': reportObj.patientobj.patientProfile.replace('http://localhost:8000', serverOrgin),
                             'patientPhoneNumber': reportObj.patientobj.patientPhonenumber,
                             'img1': reportObj.img1.replace('http://localhost:8000', serverOrgin),
                             'img2': reportObj.img2.replace('http://localhost:8000', serverOrgin),
                             'img3': reportObj.img3.replace('http://localhost:8000', serverOrgin),
                             'img4': reportObj.img4.replace('http://localhost:8000', serverOrgin),
                             'img5': reportObj.img5.replace('http://localhost:8000', serverOrgin),
                             'predictedprescription': reportObj.predictedprescription,
                             'prescription': reportObj.prescription,
                             'reportAccurate': json.loads(reportObj.reportAccurate),
                             'reportId': reportObj.id,
                             'acceptStatus': reportObj.acceptReq
                                   }
            reportMonitorList.append(reportRequest)

        return(HttpResponse(json.dumps(reportMonitorList)))
#---------------------end ------------------------

#-------------- accept request doctor ---------------
@csrf_exempt
def acceptRequestByDoctor(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = result['id']

        reportObj = patientReport.objects.get(id = reportId)
        reportObj.acceptReq = 1

        reportObj.save()
        return(HttpResponse(json.dumps('success')))

@csrf_exempt
def approvalByDoctor(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = result['id']
        reportObj = patientReport.objects.get(id = reportId)
        reportObj.acceptReq = 2
        reportObj.save()
        return(HttpResponse(json.dumps('success')))

@csrf_exempt
def respondingReportByDoctor(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = result['reportId']
        reportAnalysis = result['prescription']
        reportObj = patientReport.objects.get(id = reportId)
        reportObj.prescription = reportAnalysis
        reportObj.acceptReq = 3
        reportObj.save()
        return(HttpResponse(json.dumps('success')))
#----------------------end----------------------------
@csrf_exempt
def reportIdListPatientSide(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        patientGmailId = result['gmailId']
        patientobj  = patientInfo.objects.get(patientGmailid= patientGmailId)
        reportObjList = patientReport.objects.filter(patientobj = patientobj , acceptReq__gt = 0)
        patientreportIdanddoctorsList = []
        for patientData in reportObjList:

            msgMinInfo = {
                'reportId': patientData.id,
                'doctorGmailId':patientData.doctorGmailid
                        }
            patientreportIdanddoctorsList.append(msgMinInfo)
        return(HttpResponse(json.dumps(patientreportIdanddoctorsList)))


@csrf_exempt
def reportIdListDoctorSide(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        doctorGmailId = result['gmailId']

        reportObjList = patientReport.objects.filter(
            doctorGmailid=doctorGmailId, acceptReq__gt=0)
        doctorreportIdanddoctorsList = []
        for doctorData in reportObjList:
            msgMinInfo = {
                'reportId': doctorData.id,
                'patientGmailId': doctorData.patientobj.patientGmailid
                         }
            doctorreportIdanddoctorsList.append(msgMinInfo)
        return(HttpResponse(json.dumps(doctorreportIdanddoctorsList)))



@csrf_exempt
def sendMsg(request):

    if request.method =='POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)

        senderId = result['senderId']
        receiverId = result['receiverId']
        msg = result['message']
        reportId = result['reportId']
        time = result['time']
        messageObj = chartingBox(sendmailId = senderId , receiverId = receiverId , message = msg ,reportId=reportId , time = time)
        messageObj.save()
        return(HttpResponse(json.dumps('sended')))

@csrf_exempt
def getMsg(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        senderId = result['senderId']
        receiverId = result['receiverId']
        reportId = result['reportId']
        lastRecordId = result['lastRecordId']
        messageObjList = chartingBox.objects.filter(Q(reportId=reportId), Q(id__gte = lastRecordId))
        messageList = []
        for data in messageObjList:

            message = {
                'message':data.message,
                'send': senderId == data.sendmailId,
                'receive': receiverId == data.receiverId,
                'msgId': data.id,
                'time':data.time
                     }
            print(data.id)
            messageList.append(message)
        print(messageList)
        return(HttpResponse(json.dumps(messageList)))




#------------------- patient report is analysis by doctor
@csrf_exempt
def  patientreportAnalysis(request):
    if request.method == 'POST':
        reportList = []
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)

        reportsMontierObjList = patientReport.objects.filter(Q(doctorGmailid=result['gmailid']), Q(acceptReq=2)|Q(acceptReq=3))
        
        for reportObj in reportsMontierObjList:

            patientObj = reportObj.patientobj

            patientreport = {
                'name':patientObj.patientName,
                'gmailid':patientObj.patientGmailid,
                'phonenumber': patientObj.patientPhonenumber,
                'profile': patientObj.patientProfile.replace('http://localhost:8000', serverOrgin),
                'img1': reportObj.img1.replace('http://localhost:8000', serverOrgin),
                'img2': reportObj.img2.replace('http://localhost:8000', serverOrgin),
                'img3': reportObj.img3.replace('http://localhost:8000', serverOrgin),
                'img4': reportObj.img4.replace('http://localhost:8000', serverOrgin),
                'img5': reportObj.img5.replace('http://localhost:8000', serverOrgin),
                'predictedprescription': reportObj.predictedprescription,
                'reportAccurate': json.loads(reportObj.reportAccurate),
                'reportId': reportObj.id,
                'acceptReq': reportObj.acceptReq,
                           }
            reportList.append(patientreport)
        return(HttpResponse(json.dumps(reportList)))

@csrf_exempt
def reportData(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = result['reportId']
        reportObj = patientReport.objects.get(id=reportId)
        patientObj = reportObj.patientobj

        patientreport = {
            'name': patientObj.patientName,
            'gmailid': patientObj.patientGmailid,
            'phonenumber': patientObj.patientPhonenumber,
            'profile': patientObj.patientProfile.replace('http://localhost:8000', serverOrgin),
            'img1': reportObj.img1.replace('http://localhost:8000', serverOrgin),
            'img2': reportObj.img2.replace('http://localhost:8000', serverOrgin),
            'img3': reportObj.img3.replace('http://localhost:8000', serverOrgin),
            'img4': reportObj.img4.replace('http://localhost:8000', serverOrgin),
            'img5': reportObj.img5.replace('http://localhost:8000', serverOrgin),
            'predictedprescription': reportObj.predictedprescription,
            'reportAccurate': json.loads(reportObj.reportAccurate),
            'reportId': reportObj.id,
            'acceptReq': reportObj.acceptReq,
        }
        return(HttpResponse(json.dumps(patientreport)))

#-----------------------end----------------------------

#---- change the user state -----------------------
@csrf_exempt
def setUsersStatus(request):

    request_data = request.body.decode('utf-8')
    result = ast.literal_eval(request_data)

    activeuserObj = activeUsers.objects.get(
            usermailId=result['usermailId'], typeUser=result['typeUser'])
    activeuserObj.activeStatus = 'active'
    activeuserObj.save()

    if result['typeUser'] in [1,2]:
        return HttpResponse(json.dumps(len(activeUsers.objects.filter(typeUser = 0,activeStatus='active'))))

    doctorList = []
    deliveryboyList =[]

    for doctor in activeUsers.objects.filter(typeUser = 1 , activeStatus = 'active'):
        doctorobj = doctorInfo.objects.get(doctorGmailid = doctor.usermailId)
        doctorData = {
                        'doctorName': doctorobj.doctorName ,
                        'doctorId'  : doctorobj.id ,
                        'doctorProfile': doctorobj.doctorProfile.replace('http://localhost:8000', serverOrgin),
                        'doctorDegree': doctorobj.doctorDegree,
                        'doctorPhoneNumber':doctorobj.doctorPhonenumber,
                        'doctorGmailId': doctorobj.doctorGmailid
                     }
        print(doctorobj.doctorPhonenumber)
        doctorList.append(doctorData)

    for deliverboy in activeUsers.objects.filter(typeUser = 2 , activeStatus = 'active'):
        deliveryboyObj = deliveryboyInfo.objects.get(deliveryboyGmailid = deliverboy.usermailId)
        deliveryboyData = {
            'deliveryboyName': deliveryboyObj.deliveryboyName ,
            'deliveryboyGmailid': deliveryboyObj.deliveryboyGmailid ,
            'deliveryboyProfile': deliveryboyObj.deliveryboyProfile.replace('http://localhost:8000', serverOrgin),
            'deliveryboyPhonenumber': deliveryboyObj.deliveryboyPhonenumber,
            'deliveryboyId': deliveryboyObj.id
                          }
        deliveryboyList.append(deliveryboyData)
    
    Data = {'doctorList': doctorList, 'deliveryboyList': deliveryboyList}
    return HttpResponse(json.dumps(Data))
#--------------------------end ---------------------------------

#---------------------- DeliveryInfo-------------------


@csrf_exempt
def submitDeliveryInfo(request):

    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)


        deliveryId = result['deliveryId']
        reportId = result['reportId']
        typePrescription = result['typePrescription']
        deliveryAddress = result['address']
        patientGmailId = result['patientGmailId']
        prescription = ''
        requestStatus = 1
        print(result)
        if typePrescription == 1:

            prescription = patientReport.objects.get(id=reportId).prescription
        else:
            prescription = patientReport.objects.get(id=reportId).predictedprescription

        patientreportObj = patientReport.objects.get(id = reportId)
        deliveryBoyObj   = deliveryboyInfo.objects.get(id=deliveryId)
        deliveryInfoObj = deliveryInfo( patientReportObj = patientreportObj,
                                        deliveryboyGmailId = deliveryBoyObj.deliveryboyGmailid,
                                        OrderDetails = prescription,
                                        requestState = requestStatus,
                                        address=deliveryAddress,
                                        patientGmailid=patientGmailId)
        deliveryInfoObj.save()
        print(deliveryInfoObj.requestState)
        return HttpResponse(json.dumps('success'))

@csrf_exempt
def fetchPatientRequests(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        deliveryboyGmailId = result['deliveryboyGmailId']



        deliveryboy = deliveryInfo.objects.filter(deliveryboyGmailId=deliveryboyGmailId, requestState=1)
        deliveryInfoList = []

        for deliveryData in deliveryboy:

            deliveryInfoData = {
                'patientName': deliveryData.patientReportObj.patientobj.patientName,
                'patientProfile': deliveryData.patientReportObj.patientobj.patientProfile.replace('http://localhost:8000', serverOrgin),
                'patientGmailId': deliveryData.patientReportObj.patientobj.patientGmailid,
                'patientPhoneNumber': deliveryData.patientReportObj.patientobj.patientPhonenumber,
                'deliveryId':deliveryData.id,
                'requestStatus':deliveryData.requestState
                 }
            deliveryInfoList.append(deliveryInfoData)
        return(HttpResponse(json.dumps(deliveryInfoList)))

@csrf_exempt
def getDeliveryIdList(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        deliveryGmailId = result['deliveryGmailId']
        print(deliveryGmailId)
        deliveryIdList = []
        deliveryObjList = deliveryInfo.objects.filter( deliveryboyGmailId=deliveryGmailId , deliveryStatus__lt = 4)

        for deliveryId in deliveryObjList:
            deliveryIdList.append(deliveryId.id)

        return(HttpResponse(json.dumps(deliveryIdList)))

@csrf_exempt
def getDeliveryDataById(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        deliveryObj = deliveryInfo.objects.get( id= result['deliveryId'])
        deliveryData = {
            'patientProfie': deliveryObj.patientReportObj.patientobj.patientProfile.replace('http://localhost:8000', serverOrgin),
            'patientName': deliveryObj.patientReportObj.patientobj.patientName,
            'patientGmailid': deliveryObj.patientReportObj.patientobj.patientGmailid,
            'patientPhoneNumber': deliveryObj.patientReportObj.patientobj.patientPhonenumber,
            'deliveryPrescription':deliveryObj.OrderDetails,
            'deliveryAddress':deliveryObj.address,
            'deliveryAmount': deliveryObj.Amount,
            'requestStatus':deliveryObj.requestState,
            'deliveryStatus':deliveryObj.deliveryStatus
                     }
        return(HttpResponse(json.dumps(deliveryData)))

@csrf_exempt
def setTheAmount(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        deliveryId = result['deliveryId']
        deliveryObj = deliveryInfo.objects.get(id=deliveryId)
        deliveryObj.Amount = result['amount']
        deliveryObj.deliveryStatus = 1
        deliveryObj.save()
        return HttpResponse(json.dumps('success'))

@csrf_exempt
def setOrderStatus(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        orderstatusVal = result['orderstatusVal']
        deliveryId = result['deliveryId']
        deliveryObj = deliveryInfo.objects.get(id=deliveryId)
        deliveryObj.deliveryStatus = orderstatusVal+1
        deliveryObj.save()
        return HttpResponse(json.dumps('success'))

@csrf_exempt
def acceptPatientRequestByDeliveryBoy(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        deliveryId = result['deliveryId']

        deliveryObj = deliveryInfo.objects.get(id=deliveryId)
        deliveryObj.requestState = 2
        deliveryObj.save()
        return(HttpResponse(json.dumps('success')))

@csrf_exempt
def fetchDeliveryInfoById(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        reportId = result['reportId']

        patientReportObj = patientReport.objects.get(id=reportId)
        try:
            deliveyInfoObj = deliveryInfo.objects.get(patientReportObj = patientReportObj)
            print('my bug')
            if deliveyInfoObj.requestState > 0:
                deliverboyObj = deliveryboyInfo.objects.get(deliveryboyGmailid=deliveyInfoObj.deliveryboyGmailId)

                deliveryData = {
                    'deliveryboyProfile': deliverboyObj.deliveryboyProfile.replace('http://localhost:8000', serverOrgin),
                              'deliveryboyName': deliverboyObj.deliveryboyName,
                              'deliveryboyGmailId': deliverboyObj.deliveryboyGmailid,
                              'deliveryboyPhonenumber': deliverboyObj.deliveryboyPhonenumber,
                              'OrderStatus': deliveyInfoObj.deliveryStatus,
                              'OrderDescription': deliveyInfoObj.OrderDetails,
                              'deliveryId': deliveyInfoObj.id,
                              'address': deliveyInfoObj.address,
                              'amount': deliveyInfoObj.Amount,
                              'requestState': deliveyInfoObj.requestState,
                              'deliveryboyUpi': deliverboyObj.deliveryboyUPI.replace('http://localhost:8000', serverOrgin)
                                      }
            else:
              deliveryData = {
                'requestState': 0
                             }
        except:
            deliveryData = {
                'requestState': 0
                           }
            print('exception my bug')

        return(HttpResponse(json.dumps(deliveryData)))
#-----------------------end-----------------------------


#--------------------- email sending function --------------

@csrf_exempt
def sendOtp(request):
     if request.method == 'POST':
            request_data = request.body.decode('utf-8')
            result = ast.literal_eval(request_data)
            print(result)
            typeUser = result['typeUser']
            UserGmailid = result['gmailId']
            otp = result['otp']
            successFlage = False
            if typeUser == '0':
                
                if len(patientInfo.objects.filter(patientGmailid=UserGmailid)) == 1:
                    
                    patientObj = patientInfo.objects.get(patientGmailid=UserGmailid)
                    mailStatus = EmailSender(0,patientObj.patientProfile,otp,UserGmailid,patientObj.patientName)
                    successFlage = mailStatus ==1

            elif typeUser == '1':
                print('entered')
                if len(doctorInfo.objects.filter(doctorGmailid=UserGmailid))==1:
                    
                    doctorObj = doctorInfo.objects.get(doctorGmailid=UserGmailid)
                    mailStatus= EmailSender(1, doctorObj.doctorProfile,otp, UserGmailid,doctorObj.doctorName)
                    successFlage = mailStatus == 1

            else:

                if len(deliveryboyInfo.objects.filter(deliveryboyGmailid=UserGmailid)) == 1:

                    deliveryboyObj = deliveryboyInfo.objects.get(deliveryboyGmailid=UserGmailid)
                    mailStatus = EmailSender(2, deliveryboyObj.deliveryboyProfile,otp,UserGmailid ,deliveryboyObj.deliveryboyName )
                    successFlage = mailStatus == 1
            return(HttpResponse(json.dumps(successFlage)))

def EmailSender(typeUser,ProfilePick,otp,UserMailId,UserName):
        ProfilePick = ProfilePick.replace('http://localhost:8000', serverOrgin)
        filepath = os.path.join(BASE_DIR, 'app', 'gmailStylefile')
        fileObj = open(filepath, 'r')
        htmlBody = fileObj.read()
        
        subject, from_email, to = 'Skin Care', 'skincarecentermailcenter@gmail.com', UserMailId
        text_content = 'This is an important message.'
        html_content = " <img src='{}'  style='border-radius: 25px;width:350px;height:350px;'><br> <h4> Dear {}</h4><h5>OTP : {}</h5> <i>Regarding <br> Skincare </i>".format(ProfilePick, UserName,otp)
        htmlMsg = htmlBody.format(html_content)
        msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
        msg.attach_alternative(htmlMsg, "text/html")
        return(msg.send())
        

@csrf_exempt
def setPassword(request):
    if request.method == 'POST':
        request_data = request.body.decode('utf-8')
        result = ast.literal_eval(request_data)
        typeUser = result['typeUser']
        UserGmailid = result['gmailId']
        Password = result['password']
        if typeUser == '0':
            patientObj = patientInfo.objects.get(patientGmailid=UserGmailid)
            patientObj.patientPassword = Password
            patientObj.save()
        elif typeUser == '1':
            doctorObj = doctorInfo.objects.get(doctorGmailid=UserGmailid)
            doctorObj.doctorPassword = Password
            doctorObj.save()
        else:
            deliveryBoyObj = deliveryboyInfo.objects.get(deliveryboyGmailid=UserGmailid)
            deliveryBoyObj.deliveryboyPassword = Password
            deliveryBoyObj.save()
        return(HttpResponse(json.dumps('success')))
#------------------------end ------------------------------------



#------ finding active users ----
def set_interval(resetUserStatus, sec):
    def func_wrapper():
        set_interval(resetUserStatus, sec)
        resetUserStatus()
    t = threading.Timer(sec, func_wrapper)
    t.start()
    return t

def resetUserStatus():
    for i in activeUsers.objects.all():
        i.activeStatus = 'inactive'  # put inactivte after impleting doctor and deliveryboy home page
        i.save()


set_interval(resetUserStatus, 60*2)  #after performing migration uncomment it
#
#  # for every 2 min it reset the use status to inactivte

