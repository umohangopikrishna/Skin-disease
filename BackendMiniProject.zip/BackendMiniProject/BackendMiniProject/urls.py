"""BackendMiniProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('req/',views.skinDiseasePredictor,name = "req"),
    path('testimg/',views.imageTest,name='imagetest'),
    path('Registration/', views.Registration, name="Registration"),
    path('formValidation/', views.formValidation, name="formValidation"),
    path('setUsersStatus/', views.setUsersStatus, name="setUsersStatus"),
    path('getReport/',views.getReport,name='getReport'),
    path('showReportToDoctor/', views.showReportToDoctor, name='showReportToDoctor'),
    path('patientReport/', views.patientReport, name='patientReport'),
    path('doctorAcceptMonitoringPatient/',views.doctorAcceptMonitoringPatient, name='doctorAcceptMonitoringPatient'),
    path('patientRequestToDoctor/', views.patientRequestToDoctor,name='patientRequestToDoctor'),
    path('acceptRequestByDoctor/', views.acceptRequestByDoctor,name='acceptRequestByDoctor'),
    path('approvalByDoctor/', views.approvalByDoctor, name='approvalByDoctor'),
    path('getRecordById/', views.getRecordById, name='getRecordById'),
    path('approvalByDoctor/', views.approvalByDoctor, name='approvalByDoctor'),
    path('patientreportAnalysis/', views.patientreportAnalysis,name='patientreportAnalysis'),
    path('respondingReportByDoctor/', views.respondingReportByDoctor,name='respondingReportByDoctor'),
    path('reportData/', views.reportData, name='reportData'),
    path('getMsg/', views.getMsg, name='getMsg'),
    path('sendMsg/', views.sendMsg, name='sendMsg'),
    path('submitDeliveryInfo/', views.submitDeliveryInfo, name='submitDeliveryInfo'),
    path('fetchDeliveryInfoById/', views.fetchDeliveryInfoById, name='fetchDeliveryInfoById'),
    path('fetchPatientRequests/', views.fetchPatientRequests,name='fetchPatientRequests'),
    path('acceptPatientRequestByDeliveryBoy/', views.acceptPatientRequestByDeliveryBoy, name='acceptPatientRequestByDeliveryBoy'),
    path('getDeliveryIdList/', views.getDeliveryIdList, name='getDeliveryIdList'),
    path('getDeliveryDataById/', views.getDeliveryDataById,name='getDeliveryDataById'),
    path('setOrderStatus/', views.setOrderStatus, name='setOrderStatus'),
    path('setTheAmount/', views.setTheAmount, name='setTheAmount'),
    path('reportIdListPatientSide/', views.reportIdListPatientSide,name='reportIdListPatientSide'),
    path('reportIdListDoctorSide/', views.reportIdListDoctorSide,name='reportIdListDoctorSide'),
    path('sendOtp/', views.sendOtp, name='sendOtp'),
    path('setPassword/', views.setPassword, name='setPassword')
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
